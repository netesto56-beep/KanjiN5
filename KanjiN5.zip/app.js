// === КОНСТАНТЫ ===
const WEIGHTS = {
  unknown: 4,
  hard: 3,
  easy: 2,
  known: 1
};

const RATING_LABELS = {
  unknown: 'Не знаю',
  hard: 'Трудно',
  easy: 'Легко',
  known: 'Знаю'
};

const STORAGE_KEY = 'kanji-n5-progress';

// === DOM ===
const card = document.getElementById('card');
const frontKanji = document.getElementById('frontKanji');
const frontHint = document.getElementById('frontHint');
const backMeaning = document.getElementById('backMeaning');
const backReadings = document.getElementById('backReadings');
const backExamples = document.getElementById('backExamples');
const btnShow = document.getElementById('btnShow');
const btnNext = document.getElementById('btnNext');
const ratingButtons = document.getElementById('ratingButtons');
const ratingBtns = document.querySelectorAll('.rating-btn');
const summaryEl = document.getElementById('summary');
const filterBtns = document.querySelectorAll('.filter-btn');

// === STATE ===
let allKanji = [];           // полный массив из kanji.json
let progress = {};           // { kanji: 'unknown'|'hard'|'easy'|'known' }
let currentFilter = 'all';   // 'all' | 'unknown' | 'hard' | 'easy' | 'known'
let currentIndex = -1;       // индекс в allKanji
let lastShownIndex = -1;     // для защиты от дублей подряд
let isFlipped = false;

// === INIT ===
async function init() {
  await loadKanjiData();
  loadProgress();
  bindEvents();
  updateSummary();
  nextKanji(); // первая карточка
}

// === DATA LOADING ===
async function loadKanjiData() {
  try {
    const res = await fetch('kanji.json');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    allKanji = await res.json();
    console.log(`Загружено ${allKanji.length} кандзи`);
  } catch (e) {
    console.error('Не удалось загрузить kanji.json:', e);
    // Фоллбэк — минимум, чтобы не ломался UI
    allKanji = [
      { kanji: '日', meaning: 'солнце, день', kunyomi: ['ひ','か'], onyomi: ['ニチ','ジツ'], examples: [{word:'毎日',reading:'まいにち',meaning:'каждый день'},{word:'日曜日',reading:'にちようび',meaning:'воскресенье'},{word:'日本',reading:'にほん',meaning:'Япония'}] },
      { kanji: '月', meaning: 'луна, месяц', kunyomi: ['つき'], onyomi: ['ゲツ','ガツ'], examples: [{word:'月曜日',reading:'げつようび',meaning:'понедельник'},{word:'月刊',reading:'げっかн',meaning:'ежемесячное издание'}] },
      { kanji: '火', meaning: 'огонь', kunyomi: ['ひ'], onyomi: ['カ'], examples: [{word:'火曜日',reading:'かようび',meaning:'вторник'},{word:'火山',reading:'かざん',meaning:'вулкан'}] }
    ];
  }
}

function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    progress = raw ? JSON.parse(raw) : {};
  } catch {
    progress = {};
  }
}

function saveProgress() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
}

// === EVENTS ===
function bindEvents() {
  btnShow.addEventListener('click', () => {
    if (!isFlipped) flipCard();
  });

  btnNext.addEventListener('click', () => {
    nextKanji();
  });

  ratingBtns.forEach(btn => {
    btn.addEventListener('click', () => selectRating(btn.dataset.rating));
  });

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => setFilter(btn.dataset.filter));
  });
}

// === CARD RENDER ===
function renderCard(index) {
  if (index < 0 || index >= allKanji.length) return;
  const k = allKanji[index];
  currentIndex = index;

  // Лицевая сторона
  frontKanji.textContent = k.kanji;
  frontHint.textContent = `${k.examples[0].word} (${k.examples[0].reading})`;

  // Обратная сторона
  backMeaning.innerHTML = `
    <div class="kanji-large" style="margin-bottom: 8px;">${k.kanji}</div>
    <div>${k.meaning}</div>
  `;
  backReadings.innerHTML = `
    <span class="reading-item"><strong>Кун:</strong> ${k.kunyomi.join('、')}</span>
    <span class="reading-item"><strong>Он:</strong> ${k.onyomi.join('、')}</span>
  `;
  backExamples.innerHTML = k.examples.map(ex => `
    <div class="example-row">
      <span class="example-word">${ex.word}</span>
      <span class="example-reading">${ex.reading}</span>
      <span class="example-meaning">${ex.meaning}</span>
    </div>
  `).join('');

  // Сброс UI состояния карточки
  resetCardUI();
}

function resetCardUI() {
  // Мгновенный сброс флипа БЕЗ анимации + сброс UI кнопок
  card.style.transition = 'none';
  card.classList.remove('flipped');
  card.offsetHeight; // форсируем рефлоу
  card.style.transition = '';

  isFlipped = false;
  btnShow.style.display = 'block';
  ratingButtons.style.display = 'none';
  btnNext.style.display = 'none';
  ratingBtns.forEach(b => b.classList.remove('selected'));

  // Подсветка текущей оценки этой карточки (если уже была)
  const currentKanji = allKanji[currentIndex]?.kanji;
  if (currentKanji && progress[currentKanji]) {
    const savedRating = progress[currentKanji];
    const btn = document.querySelector(`.rating-btn[data-rating="${savedRating}"]`);
    if (btn) btn.classList.add('selected');
  }
}

function flipCard() {
  card.classList.add('flipped');
  isFlipped = true;
  btnShow.style.display = 'none';
  ratingButtons.style.display = 'grid';
}

function selectRating(rating) {
  const kanji = allKanji[currentIndex]?.kanji;
  if (!kanji) return;

  progress[kanji] = rating;
  saveProgress();

  ratingBtns.forEach(b => b.classList.toggle('selected', b.dataset.rating === rating));
  btnNext.style.display = 'block';
  updateSummary();
}

// === WEIGHTED RANDOM SELECTION ===
function getFilteredIndices() {
  return allKanji
    .map((k, i) => ({ index: i, kanji: k.kanji, rating: progress[k.kanji] || 'unknown' }))
    .filter(item => currentFilter === 'all' || item.rating === currentFilter);
}

function pickNextIndex() {
  const candidates = getFilteredIndices();
  if (candidates.length === 0) return -1; // нет карточек под фильтр

  // Если только одна карточка — возвращаем её
  if (candidates.length === 1) return candidates[0].index;

  // Взвешенный выбор
  const totalWeight = candidates.reduce((sum, c) => sum + WEIGHTS[c.rating], 0);
  let random = Math.random() * totalWeight;

  for (const c of candidates) {
    random -= WEIGHTS[c.rating];
    if (random <= 0) {
      // Защита от дубля подряд
      if (c.index === lastShownIndex && candidates.length > 1) {
        // Попробуем следующую по весу (просто берём другую случайно из оставшихся)
        const others = candidates.filter(x => x.index !== lastShownIndex);
        const otherWeights = others.reduce((s, x) => s + WEIGHTS[x.rating], 0);
        let r2 = Math.random() * otherWeights;
        for (const o of others) {
          r2 -= WEIGHTS[o.rating];
          if (r2 <= 0) return o.index;
        }
        return others[0].index; // фоллбэк
      }
      return c.index;
    }
  }

  return candidates[0].index; // фоллбэк
}

function nextKanji() {
  const next = pickNextIndex();
  if (next === -1) {
    const allIndices = allKanji.map((_, i) => i).filter(i => i !== lastShownIndex);
    if (allIndices.length === 0) return;
    resetCardUI();
    renderCard(allIndices[0]);
    lastShownIndex = allIndices[0];
    return;
  }
  resetCardUI();
  renderCard(next);
  lastShownIndex = next;
}

// === SUMMARY & FILTER ===
function updateSummary() {
  const counts = { unknown: 0, hard: 0, easy: 0, known: 0 };
  for (const rating of Object.values(progress)) {
    if (counts[rating] !== undefined) counts[rating]++;
  }
  // Карточки без прогресса считаются 'unknown'
  const withoutProgress = allKanji.length - Object.keys(progress).length;
  if (withoutProgress > 0) counts.unknown += withoutProgress;

  summaryEl.textContent =
    `Не знаю: ${counts.unknown} | Трудно: ${counts.hard} | Легко: ${counts.easy} | Знаю: ${counts.known}`;
}

function setFilter(filter) {
  currentFilter = filter;
  filterBtns.forEach(b => b.classList.toggle('active', b.dataset.filter === filter));
  // Сразу подбираем карточку под новый фильтр
  nextKanji();
}

// === START ===
init();